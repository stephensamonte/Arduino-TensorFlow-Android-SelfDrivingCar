# Arduino-Android-USB
Simple Android Application to interface an Arduino with an Android phone using an USB cable.

Made using felHR85's [UsbSerial Library](https://github.com/felHR85/UsbSerial)

